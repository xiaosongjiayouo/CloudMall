package com.atguigu.spzx.common.log.annotation;

import com.atguigu.spzx.common.log.enums.OperatorType;

import java.lang.annotation.*;

/**
 * 元注解：修饰注解的注解
 * @Target:当前注解可以修改的位置
 * TYPE:类
 * METHOD:方法
 * FIELD:字段
 * PARAMETER:参数
 *
 *@Retention:声明周期
 *
 * SOURCE：源码
 * CLASS：字节码
 * RUNTIME： 运行时
 *
 *  java--class --内存
 *
 *  @Inherited 继承
 *  当前注解如果加在父类中，子类会不会收到影响
 *
 *  @Documented 文档生成
 *   javaDoc
 *
 */
@Target({ ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
//@Inherited
//@Documented
public @interface Log {
    // 模块名称
    public String title() ;
    // 操作人类别
    public OperatorType operatorType() default OperatorType.MANAGE;
    // 业务类型（0其它 1新增 2修改 3删除）
    public int businessType() ;
    // 是否保存请求的参数
    public boolean isSaveRequestData() default true;
    // 是否保存响应的参数
    public boolean isSaveResponseData() default true;

}
