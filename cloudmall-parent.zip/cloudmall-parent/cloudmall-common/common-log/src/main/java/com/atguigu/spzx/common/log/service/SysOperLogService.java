package com.atguigu.spzx.common.log.service;

import com.atguigu.spzx.model.entity.system.SysOperLog;

public interface SysOperLogService {
    /**
     * 执行保存日志
     * @param sysOperLog
     */
    void saveSysOperLog(SysOperLog sysOperLog);
}
