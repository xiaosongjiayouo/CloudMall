package com.atguigu.spzx.common.log.enums;

public enum OperatorType {		// 操作人类别
    OTHER,		// 其他
    MANAGE,		// 后台用户
    MOBILE		// 手机端用户
}