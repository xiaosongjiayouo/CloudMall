package com.atguigu.spzx.product.service;

import com.atguigu.spzx.model.entity.product.Brand;

import java.util.List;

public interface BrandService {
    /**
     * 获取所有品牌信息
     * @return
     */
    List<Brand> findAll();

}
