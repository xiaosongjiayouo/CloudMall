package com.atguigu.spzx.product.service.impl;

import com.alibaba.fastjson.JSON;
import com.atguigu.spzx.model.entity.product.Category;
import com.atguigu.spzx.product.mapper.CategoryMapper;
import com.atguigu.spzx.product.service.CategoryService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryMapper categoryMapper;


    @Autowired
    private RedisTemplate<String,String> redisTemplate;



    /**
     * 查询一级分类列表
     *
     * key的命名要求：
     *  1.唯一，重复会覆盖
     *  2.见名知意
     *   category:one
     *   : 表示存储redis有类似目录的层级结构
     *
     * @return
     */
    @Override
    public List<Category> findOneCategory() {
        //1.从redis中获取数据
        String categoryJSON = redisTemplate.opsForValue().get("category:one");
        //判断是否存在
        if(!StringUtils.isEmpty(categoryJSON)){
            //转换类型返回即可
            List<Category> categoryList = JSON.parseArray(categoryJSON, Category.class);
            //返回
            return categoryList;
        }


        //redis中不存在，查询数据库
        List<Category> oneCategory = categoryMapper.findOneCategory();
        //存储到redis
        redisTemplate.opsForValue().set("category:one", JSON.toJSONString(oneCategory),7, TimeUnit.DAYS);

        return oneCategory;
    }

//    /**
//     * 查询一级分类列表
//     *
//     * @return
//     */
//    @Override
//    public List<Category> findOneCategory() {
//        return categoryMapper.findOneCategory();
//    }

    /**
     * 获取分类树形数据
     *
     * @return
     * category:all
     */
    @Override
    @Cacheable(value = "category",key = "'all'")
    public List<Category> findCategoryTree() {
        //查询所有分类
        List<Category> categoryList = categoryMapper.findAll();
        //处理分类列表-绑定从属关系
        //获取一级分类列表
        List<Category> categoryOneList = categoryList.stream().filter(category -> {
            return category.getParentId().intValue() == 0;
        }).collect(Collectors.toList());

        //遍历获取二级分类列表设置到一的children
        //判断
        if (!CollectionUtils.isEmpty(categoryOneList)) {

            categoryOneList.stream().forEach(category -> {

                //遍历所有分类列表，获取于当前的一级分类id相同的parentId
                List<Category> categoryTwoList = categoryList.stream().filter(item -> {

                    return category.getId().intValue() == item.getParentId().intValue();

                }).collect(Collectors.toList());

                //设置二级分类
                category.setChildren(categoryTwoList);

                //判断
                if (!CollectionUtils.isEmpty(categoryTwoList)) {

                    categoryTwoList.forEach(category2 -> {
                        //category2二级分类对象

                        //获取三级分类列表
                        List<Category> categoryThreeList = categoryList.stream().filter(item -> {


                            return category2.getId().intValue() == item.getParentId().intValue();
                        }).collect(Collectors.toList());

                        //设置三级分类列表到二级children
                        category2.setChildren(categoryThreeList);

                    });


                }


            });

        }


        return categoryOneList;
    }
}
