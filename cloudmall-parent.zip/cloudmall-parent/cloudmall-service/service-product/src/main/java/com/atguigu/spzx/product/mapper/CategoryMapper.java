package com.atguigu.spzx.product.mapper;

import com.atguigu.spzx.model.entity.product.Category;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CategoryMapper {
    /**
     * 查询一级分类列表
     * @return
     */
    List<Category> findOneCategory();

    /**
     * 获取分类列表
     * @return
     */
    List<Category> findAll();
}
