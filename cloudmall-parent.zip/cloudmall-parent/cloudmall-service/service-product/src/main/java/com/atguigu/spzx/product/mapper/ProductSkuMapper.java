package com.atguigu.spzx.product.mapper;

import com.atguigu.spzx.model.dto.h5.ProductSkuDto;
import com.atguigu.spzx.model.entity.product.ProductSku;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ProductSkuMapper {
    /**
     * 获取畅销商品列表
     * @return
     */
    List<ProductSku> findProductSkuBySale();

    /**
     * 条件分页查询商品列表
     * @param productSkuDto
     * @return
     */
    List<ProductSku> findByPage(ProductSkuDto productSkuDto);
}
