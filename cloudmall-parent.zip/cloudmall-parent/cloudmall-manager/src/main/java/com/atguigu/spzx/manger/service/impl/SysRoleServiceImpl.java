package com.atguigu.spzx.manger.service.impl;

import com.atguigu.spzx.manger.mapper.SysRoleMapper;
import com.atguigu.spzx.manger.mapper.SysRoleUserMapper;
import com.atguigu.spzx.manger.service.SysRoleService;
import com.atguigu.spzx.model.dto.system.SysRoleDto;
import com.atguigu.spzx.model.entity.system.SysRole;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections4.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.stylesheets.LinkStyle;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SysRoleServiceImpl implements SysRoleService {


    @Autowired
    private SysRoleMapper sysRoleMapper;

    @Autowired
    private SysRoleUserMapper sysRoleUserMapper;
    /**
     * 条件分页查询角色列表
     * @param sysRoleDto
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public PageInfo<SysRole> findByPage(SysRoleDto sysRoleDto, Integer pageNum, Integer pageSize) {
        //封装分页查询条件
        PageHelper.startPage(pageNum,pageSize);
        //查询角色列表
        List<SysRole> sysRoleList=sysRoleMapper.findByPage(sysRoleDto);
        //转换数据类型
        return new PageInfo<>(sysRoleList);
    }

    /**
     * 保存角色
     * @param sysRole
     */
    @Override
    public void saveSysRole(SysRole sysRole) {
        sysRoleMapper.saveSysRole(sysRole);

    }

    /**
     * 修改保存
     * @param sysRole
     */
    @Override
    public void updateSysRole(SysRole sysRole) {
        sysRoleMapper.updateSysRole(sysRole);
    }

    /**
     * 根据id删除角色
     * @param id
     */
    @Override
    public void deleteSysRoleById(Long id) {
        sysRoleMapper.deleteSysRoleById(id);
    }

    /**
     * 查询所有角色
     * @return
     */
    @Override
    public Map<String,Object> findAllRoles(Long userId) {
        //创建对象封装数据
        Map<String,Object> resulMap= new HashMap<>();
        //查询所有的角色
        List<SysRole> allRoles = sysRoleMapper.findAllRoles();
        //查询当前用户拥有的角色id-->回显
        List<Long> roleIds=sysRoleUserMapper.selectRoleIdsByUserId(userId);
        resulMap.put("allRoles",allRoles);
        resulMap.put("roleIds",roleIds);

        return resulMap;
    }
}
