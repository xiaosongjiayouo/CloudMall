package com.atguigu.spzx.manger.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface SysRoleUserMapper {
    /**
     * 删除指定用户的角色
     * @param userId
     */
    void deleteByUserId(Long userId);

    /**
     * 保存用户分配角色
     * @param roleId
     * @param userId
     */
    void dodoAssign(@Param("roleId") Long roleId, @Param("userId") Long userId);

    /**
     * 查询当前用户的角色id集合
     * @param userId
     * @return
     */
    List<Long> selectRoleIdsByUserId(Long userId);
}
