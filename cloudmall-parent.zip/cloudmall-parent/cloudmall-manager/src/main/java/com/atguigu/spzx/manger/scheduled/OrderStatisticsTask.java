package com.atguigu.spzx.manger.scheduled;

import cn.hutool.core.date.DateUtil;
import com.atguigu.spzx.manger.mapper.OrderInfoMapper;
import com.atguigu.spzx.manger.mapper.OrderStatisticsMapper;
import com.atguigu.spzx.model.entity.order.OrderInfo;
import com.atguigu.spzx.model.entity.order.OrderStatistics;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class OrderStatisticsTask {

    @Autowired
    private OrderInfoMapper orderInfoMapper;

    @Autowired
    private OrderStatisticsMapper orderStatisticsMapper;
    /**
     * 秒 分 时 日 月 周 年（可以省略）
     *
     * 特点： *每
     *     日 和周 相冲的特点  其中一个必须为？表示忽略
     *
     */
//    @Scheduled(cron = "0 0 2 * * ?")
//    @Scheduled(cron = "0/2 * * * * ?")
//    @Scheduled(cron = "2,5,45,50 * * * * ?")
//    @Scheduled(cron = "30-40 * * * * ?")
    public void helloWorldTask(){

        System.out.println("helloword");
    }

    public static void main(String[] args) {
        //获取上一天的时间 例如 yyyy-MM-dd


    }

//    @Scheduled(cron = "0 0 2 * * ?")
//    @Scheduled(cron = "0/5 * * * * ?")
    public void orderTotalAmountStatistics(){

        //获取上一天的时间 例如 yyyy-MM-dd
        String dateTime = DateUtil.offsetDay(new Date(), -1).toString(new SimpleDateFormat("yyyy-MM-dd"));


        //查询
        OrderStatistics orderStatistics= orderInfoMapper.selectOrderStatistics(dateTime);
        //判断
        if(orderStatistics!=null){

            orderStatisticsMapper.insert(orderStatistics);

        }



    }
}
