package com.atguigu.spzx.manger.service.impl;

import com.atguigu.spzx.common.log.service.SysOperLogService;

import com.atguigu.spzx.manger.mapper.SysOperLogMaper;
import com.atguigu.spzx.model.entity.system.SysOperLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SysOperLogServiceImpl implements SysOperLogService {

    @Autowired
    private SysOperLogMaper sysOperLogMaper;

    /**
     * 保存日志信息
     * @param sysOperLog
     */
    @Override
    public void saveSysOperLog(SysOperLog sysOperLog) {

        sysOperLogMaper.saveSysOperLog(sysOperLog);


    }

}
