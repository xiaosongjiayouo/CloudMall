package com.atguigu.spzx.manger.service;

import com.atguigu.spzx.model.vo.system.ValidateCodeVo;

public interface ValidateCodeService {
    /**
     * 获取验证码
     * @return
     */
    ValidateCodeVo generateValidateCode();

}
