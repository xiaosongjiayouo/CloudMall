package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.entity.product.Brand;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BrandMapper {
    /**
     * 分页查询品牌列表
     * @return
     */
    List<Brand> findByPage();

    /**
     * 新增品牌
     * @param brand
     */
    void save(Brand brand);

    /**
     * 修改品牌
     * @param brand
     */
    void updateById(Brand brand);

    /**
     * 根据id删除品牌
     * @param id
     */
    void deleteById(Long id);

    /**
     * 查询所有品牌
     * @return
     */
    List<Brand> findAll();
}
