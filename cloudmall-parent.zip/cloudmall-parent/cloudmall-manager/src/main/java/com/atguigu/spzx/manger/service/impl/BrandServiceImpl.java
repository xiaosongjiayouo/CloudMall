package com.atguigu.spzx.manger.service.impl;

import com.atguigu.spzx.manger.mapper.BrandMapper;
import com.atguigu.spzx.manger.service.BrandService;
import com.atguigu.spzx.model.entity.product.Brand;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BrandServiceImpl  implements BrandService {

    @Autowired
    private BrandMapper brandMapper;
    /**
     * 分页查询品牌列表
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public PageInfo<Brand> findByPage(Integer pageNum, Integer pageSize) {
        //开启分页
        PageHelper.startPage(pageNum,pageSize);
        //查询数据
       List<Brand> brandList= brandMapper.findByPage();
        //封装数据
        PageInfo<Brand> pageInfo = new PageInfo<>(brandList);

        return pageInfo;
    }

    /**
     * 新增品牌
     * @param brand
     */
    @Override
    public void save(Brand brand) {
        brandMapper.save(brand);
    }

    /**
     * 修改品牌
     * @param brand
     */
    @Override
    public void updateById(Brand brand) {
        brandMapper.updateById(brand);

    }

    /**
     * 根据id删除品牌
     * @param id
     */
    @Override
    public void deleteById(Long id) {

        brandMapper.deleteById(id);
    }

    /**
     * 查询所有品牌
     * @return
     */
    @Override
    public List<Brand> findAll() {
        return brandMapper.findAll();
    }
}
