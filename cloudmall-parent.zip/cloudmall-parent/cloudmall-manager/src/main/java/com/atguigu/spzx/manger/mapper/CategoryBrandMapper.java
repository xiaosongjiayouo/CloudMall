package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.dto.product.CategoryBrandDto;
import com.atguigu.spzx.model.entity.product.Brand;
import com.atguigu.spzx.model.entity.product.CategoryBrand;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CategoryBrandMapper {
    /**
     * 分页条件查询分类品牌列表
     * @param categoryBrandDto
     * @return
     */
    List<CategoryBrand> findByPage(CategoryBrandDto categoryBrandDto);

    /**
     * 新增品牌
     * @param categoryBrand
     */
    void save(CategoryBrand categoryBrand);

    /**
     * 修改分类品牌
     * @param categoryBrand
     */
    void updateById(CategoryBrand categoryBrand);

    /**
     *  删除分类品牌
     * @param id
     */
    void deleteById(Long id);

    /**
     * 根据分类查询品牌列表
     * @param categoryId
     * @return
     */
    List<Brand> findBrandByCategoryId(Long categoryId);
}
