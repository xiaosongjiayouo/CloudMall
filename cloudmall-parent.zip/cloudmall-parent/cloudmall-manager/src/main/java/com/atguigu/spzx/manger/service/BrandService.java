package com.atguigu.spzx.manger.service;

import com.atguigu.spzx.model.entity.product.Brand;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface BrandService {
    /**
     * 分页查询品牌列表
     * @param pageNum
     * @param pageSize
     * @return
     */
    PageInfo<Brand> findByPage(Integer pageNum, Integer pageSize);

    /**
     * 新增品牌
     * @param brand
     */
    void save(Brand brand);

    /**
     * 修改品牌
     * @param brand
     */
    void updateById(Brand brand);

    /**
     * 根据id删除品牌
     * @param id
     */
    void deleteById(Long id);

    /**
     * 查询所有品牌
     * @return
     */
    List<Brand> findAll();


}
