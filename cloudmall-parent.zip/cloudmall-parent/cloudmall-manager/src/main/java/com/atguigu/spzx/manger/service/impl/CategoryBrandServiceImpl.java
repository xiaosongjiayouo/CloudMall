package com.atguigu.spzx.manger.service.impl;

import com.atguigu.spzx.common.log.annotation.Log;
import com.atguigu.spzx.manger.mapper.CategoryBrandMapper;
import com.atguigu.spzx.manger.service.CategoryBrandService;
import com.atguigu.spzx.model.dto.product.CategoryBrandDto;
import com.atguigu.spzx.model.entity.product.Brand;
import com.atguigu.spzx.model.entity.product.CategoryBrand;
import com.atguigu.spzx.model.vo.common.ResultCodeEnum;
import com.atguigu.spzx.service.exception.GuiguException;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service
public class CategoryBrandServiceImpl  implements CategoryBrandService {

    @Autowired
    private CategoryBrandMapper categoryBrandMapper;

    /**
     * 分页条件查询分类品牌列表
     * @param page
     * @param limit
     * @param categoryBrandDto
     * @return
     */
    @Override
    public PageInfo<CategoryBrand> findByPage(Integer page, Integer limit, CategoryBrandDto categoryBrandDto) {
        //分页插件设置
        PageHelper.startPage(page,limit);
        //条件查询分类品牌列表
        List<CategoryBrand> categoryBrandList=categoryBrandMapper.findByPage(categoryBrandDto);
        //封装数据
        return new PageInfo<>(categoryBrandList);
    }

    /**
     * 新增品牌
     * @param categoryBrand
     */
    @Override
    @Transactional
    public void save(CategoryBrand categoryBrand) {

        CategoryBrandDto categoryBrandDto = new CategoryBrandDto();
        categoryBrandDto.setCategoryId(categoryBrand.getCategoryId());
        categoryBrandDto.setBrandId(categoryBrand.getBrandId());


        //根据categoryId和brandId作为条件查询数据
        List<CategoryBrand> brandList = categoryBrandMapper.findByPage(categoryBrandDto);
        //判断
        if(!CollectionUtils.isEmpty(brandList)){
            throw  new GuiguException(ResultCodeEnum.CATEGORYBRAND_RES_IS_EXISTS);
        }


        categoryBrandMapper.save(categoryBrand);
    }

    /**
     * 修改分类品牌
     * @param categoryBrand
     */
    @Override
    public void updateById(CategoryBrand categoryBrand) {



        categoryBrandMapper.updateById(categoryBrand);

    }

    /**
     *  删除分类品牌
     * @param id
     */
    @Override
    public void deleteById(Long id) {

        categoryBrandMapper.deleteById(id);
    }

    /**
     * 根据分类查询品牌列表
     * @param categoryId
     * @return
     */
    @Override
    public List<Brand> findBrandByCategoryId(Long categoryId) {
        return categoryBrandMapper.findBrandByCategoryId(categoryId);
    }
}
