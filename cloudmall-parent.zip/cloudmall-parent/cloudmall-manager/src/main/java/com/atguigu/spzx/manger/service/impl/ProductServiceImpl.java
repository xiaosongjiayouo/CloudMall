package com.atguigu.spzx.manger.service.impl;

import com.atguigu.spzx.manger.mapper.ProductDetailsMapper;
import com.atguigu.spzx.manger.mapper.ProductMapper;
import com.atguigu.spzx.manger.mapper.ProductSkuMapper;
import com.atguigu.spzx.manger.service.ProductService;
import com.atguigu.spzx.model.dto.product.ProductDto;
import com.atguigu.spzx.model.entity.product.Product;
import com.atguigu.spzx.model.entity.product.ProductDetails;
import com.atguigu.spzx.model.entity.product.ProductSku;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.Collection;
import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private ProductSkuMapper productSkuMapper;

    @Autowired
    private ProductDetailsMapper productDetailsMapper;

    /**
     * 条件分页查询商品列表
     *
     * @param pageNum
     * @param pageSize
     * @param productDto
     * @return
     */
    @Override
    public PageInfo<Product> findByPage(Integer pageNum, Integer pageSize, ProductDto productDto) {

        //设置分页
        PageHelper.startPage(pageNum, pageSize);
        //根据条件分页查询商品列表
        List<Product> productList = productMapper.findByPage(productDto);


        return new PageInfo<>(productList);
    }

    /**
     * 保存商品
     * 涉及到几张表
     * product
     * product_details
     * product_sku
     *
     * @param product
     * @Transactional 特点：默认情况下只能拦截运行时一场 RuntimeException
     * 但是： IOException SQLException 不在RuntimeException体系下
     * <p>
     * 处理扩大异常范围
     * Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void save(Product product) {
        //保存product
        product.setStatus(0);
        product.setAuditStatus(0);
        productMapper.save(product);

        //保存product_detail
        ProductDetails productDetails = new ProductDetails();
        productDetails.setProductId(product.getId());
        productDetails.setImageUrls(product.getDetailsImageUrls());
        productDetailsMapper.save(productDetails);


        //保存 product_sku
        List<ProductSku> productSkuList = product.getProductSkuList();
        //遍历设置数据


        //定义变量
        int index = 0;
        for (ProductSku productSku : productSkuList) {
            //生成sku_code
            productSku.setSkuCode(product.getId() + "_" + index);
            //生成sku_name
            productSku.setSkuName(product.getName() + productSku.getSkuSpec());
            //设置product_id
            productSku.setProductId(product.getId());
            //设置销量
            productSku.setSaleNum(0);
            //状态
            productSku.setStatus(0);

            index++;

            //保存
            productSkuMapper.save(productSku);

        }


    }

    /**
     * 根据id查询商品对象
     *
     * @param id
     * @return
     */
    @Override
    public Product getProductById(Long id) {

        //1.查询商品信息
        Product product = productMapper.selectByProductId(id);
        //2.查询商品sku列表
        List<ProductSku> productSkuList = productSkuMapper.selectByProductId(id);
        product.setProductSkuList(productSkuList);
        //3.查询商品详情信息
        ProductDetails productDetails=productDetailsMapper.selectByProductId(id);
        product.setDetailsImageUrls(productDetails.getImageUrls());
        return product;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateById(Product product) {
        //保存商品信息
        productMapper.updateById(product);
        //保存商品sku信息
        List<ProductSku> productSkuList = product.getProductSkuList();
        //判断
        if(!CollectionUtils.isEmpty(productSkuList)){
            for (ProductSku productSku : productSkuList) {

                productSkuMapper.updateById(productSku);

            }

        }

        //保存商品详情信息
        //查询商品请求
        ProductDetails productDetails = productDetailsMapper.selectByProductId(product.getId());

        productDetails.setImageUrls(product.getDetailsImageUrls());


        productDetailsMapper.updateById(productDetails);



    }

    /**
     * 根据id删除商品信息
     * @param id
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void deleteById(Long id) {

        //删除product
        productMapper.deleteById(id);
        //删除productSKU
        productSkuMapper.deleteByProductId(id);

        //删除productDetails
        productDetailsMapper.deleteByProductId(id);


    }

    /**
     * 商品审核
     * @param id
     * @param auditStatus
     */
    @Override
    public void updateAuditStatus(Long id, Integer auditStatus) {
        //查询商品信息
        Product product = productMapper.selectByProductId(id);
        //设置数据
        if(auditStatus.intValue()==1){
            product.setAuditStatus(auditStatus);
            product.setAuditMessage("审核通过");

        }else{
            product.setAuditStatus(auditStatus);
            product.setAuditMessage("审核不通过");


        }

        productMapper.updateById(product);


    }

    /**
     * 商品上下架
     * @param id
     * @param status
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStatus(Long id, Integer status) {
        //查询商品信息
        Product product = productMapper.selectByProductId(id);
        //设置数据
        if(status.intValue()==1){
            product.setStatus(status);
        }else{
            product.setStatus(status);
        }
        productMapper.updateById(product);

        List<ProductSku> productSkuList = productSkuMapper.selectByProductId(id);

        //遍历
        for (ProductSku productSku : productSkuList) {
            productSku.setStatus(status);

            //sku上下架
            productSkuMapper.updateById(productSku);
        }

        //写sql  update product_sku  set status=#{status} where product_id=#{productId}






    }
}
