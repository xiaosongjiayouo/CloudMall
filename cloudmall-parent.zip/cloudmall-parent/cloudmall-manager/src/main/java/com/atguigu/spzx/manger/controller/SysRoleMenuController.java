package com.atguigu.spzx.manger.controller;

import com.atguigu.spzx.manger.service.SysRoleMenuService;
import com.atguigu.spzx.model.dto.system.AssginMenuDto;
import com.atguigu.spzx.model.vo.common.Result;
import com.atguigu.spzx.model.vo.common.ResultCodeEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/admin/system/sysRoleMenu")
public class SysRoleMenuController {

    @Autowired
    private SysRoleMenuService sysRoleMenuService;


    /**
     * 给指定角色分配菜单
     * @param assginMenuDto
     * @return
     */
    @PostMapping("/doAssign")
    public  Result doAssign(@RequestBody AssginMenuDto assginMenuDto){

        sysRoleMenuService.doAssign(assginMenuDto);

       return Result.build(null,ResultCodeEnum.SUCCESS);
    }

    /**
     * 查询所有菜单和当前角色拥有的菜单id集合
     * @param roleId
     * @return
     */
    @GetMapping("/findSysRoleMenuByRoleId/{roleId}")
    public Result<Map<String,Object>> findSysRoleMenuByRoleId(@PathVariable Long roleId){
        Map<String,Object>resultMap=sysRoleMenuService.findSysRoleMenuByRoleId(roleId);

        return Result.build(resultMap, ResultCodeEnum.SUCCESS);
    }
}
