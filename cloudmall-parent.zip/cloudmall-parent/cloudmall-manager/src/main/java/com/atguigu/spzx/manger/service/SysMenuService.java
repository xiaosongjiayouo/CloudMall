package com.atguigu.spzx.manger.service;

import com.atguigu.spzx.model.entity.system.SysMenu;
import com.atguigu.spzx.model.vo.system.SysMenuVo;

import java.util.List;

public interface SysMenuService {
    /**
     * 查询所有菜单
     * @return
     */
    List<SysMenu> findNodes();

    /**
     * 新增菜单
     * @param sysMenu
     */
    void save(SysMenu sysMenu);

    /**
     * 修改菜单
     * @param sysMenu
     */
    void updateById(SysMenu sysMenu);

    /**
     * 根据id删除菜单
     * @param id
     */
    void removeById(Long id);

    List<SysMenuVo> menus();

}
