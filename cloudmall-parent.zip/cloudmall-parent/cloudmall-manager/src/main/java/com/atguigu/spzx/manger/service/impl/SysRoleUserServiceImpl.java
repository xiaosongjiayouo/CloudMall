package com.atguigu.spzx.manger.service.impl;

import com.atguigu.spzx.common.log.annotation.Log;
import com.atguigu.spzx.manger.mapper.SysRoleUserMapper;
import com.atguigu.spzx.manger.service.SysRoleUserService;
import com.atguigu.spzx.model.dto.system.AssginRoleDto;
import com.atguigu.spzx.model.entity.system.SysRoleUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class SysRoleUserServiceImpl implements SysRoleUserService {

    @Autowired
    private SysRoleUserMapper sysRoleUserMapper;

    /**
     * 保存分配角色
     * @param assginRoleDto
     */
    @Override
    @Transactional
    @Log(title = "保存分类和品牌的关联",businessType = 1)
    public void doAssign(AssginRoleDto assginRoleDto) {

        //删除当前用户原来的角色
        sysRoleUserMapper.deleteByUserId(assginRoleDto.getUserId());


         int i=1/0;
        //保存
        List<Long> roleIdList = assginRoleDto.getRoleIdList();
        //遍历
        roleIdList.forEach(roleId->{

            sysRoleUserMapper.dodoAssign(roleId,assginRoleDto.getUserId());

        });


    }
}
