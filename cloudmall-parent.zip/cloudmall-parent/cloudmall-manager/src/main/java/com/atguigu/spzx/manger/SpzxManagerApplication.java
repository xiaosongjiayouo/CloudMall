package com.atguigu.spzx.manger;

import com.atguigu.spzx.common.log.annotation.EnableLogAspect;
import com.atguigu.spzx.manger.properties.MinioProperties;
import com.atguigu.spzx.manger.properties.UserAuthProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@EnableLogAspect
@ComponentScan(basePackages = "com.atguigu.spzx")
@EnableConfigurationProperties(value = {UserAuthProperties.class, MinioProperties.class})
public class SpzxManagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpzxManagerApplication.class,args);
    }
}
