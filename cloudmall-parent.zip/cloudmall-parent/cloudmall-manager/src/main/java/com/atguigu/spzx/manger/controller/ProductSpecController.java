package com.atguigu.spzx.manger.controller;

import com.atguigu.spzx.manger.service.ProductSpecService;
import com.atguigu.spzx.model.entity.product.ProductSpec;
import com.atguigu.spzx.model.vo.common.Result;
import com.atguigu.spzx.model.vo.common.ResultCodeEnum;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/product/productSpec")
public class ProductSpecController {

    @Autowired
    private ProductSpecService productSpecService;


    /**
     * 查询所有的规格
     * @return
     */
    @GetMapping("/findAll")
    public Result<List<ProductSpec>> findAll(){
        List<ProductSpec> specList=productSpecService.findAll();
        return Result.build(specList,ResultCodeEnum.SUCCESS);
    }

    /**
     * 删除规格
     * @param id
     * @return
     */
    @DeleteMapping("/deleteById/{id}")
    public Result deleteById(@PathVariable Long id){

        productSpecService.deleteById(id);
        return Result.build(null,ResultCodeEnum.SUCCESS);
    }

    /**
     * 修改商品规格
     * @param productSpec
     */
    @PutMapping("/updateById")
    public Result updateById(@RequestBody ProductSpec productSpec){

        productSpecService.updateById(productSpec);
        return Result.build(null,ResultCodeEnum.SUCCESS);
    }

    /**
     * 商品规格新增
     * @param productSpec
     * @return
     */
    @PostMapping("/save")
    public Result save(@RequestBody ProductSpec productSpec){

        productSpecService.save(productSpec);

        return Result.build(null,ResultCodeEnum.SUCCESS);
    }

    /**
     * 分页查询商品规格
     * @param pageNum
     * @param pageSize
     * @return
     */
    @GetMapping("/{pageNum}/{pageSize}")
    public Result<PageInfo<ProductSpec>> findByPage(@PathVariable Integer pageNum,
                                                    @PathVariable Integer pageSize){
        PageInfo<ProductSpec> pageInfo=productSpecService.findByPage(pageNum,pageSize);

        return Result.build(pageInfo, ResultCodeEnum.SUCCESS);
    }


}
