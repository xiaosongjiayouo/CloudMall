package com.atguigu.spzx.manger.service.impl;

import com.atguigu.spzx.manger.helper.MenuHelper;
import com.atguigu.spzx.manger.mapper.SysMenuMapper;
import com.atguigu.spzx.manger.service.SysMenuService;
import com.atguigu.spzx.model.entity.system.SysMenu;
import com.atguigu.spzx.model.vo.common.ResultCodeEnum;
import com.atguigu.spzx.model.vo.system.SysMenuVo;
import com.atguigu.spzx.service.exception.GuiguException;
import com.atguigu.spzx.utils.AuthContextUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Service
public class SysMenuServiceImpl implements SysMenuService {

    @Autowired
    private SysMenuMapper sysMenuMapper;
    /**
     * 查询所有菜单数据
     * @return
     */
    @Override
    public List<SysMenu> findNodes() {

        //查询所有菜单数据
        List<SysMenu> sysMenuList=sysMenuMapper.findNodes();
        //判断
        if(CollectionUtils.isEmpty(sysMenuList)) return null;
        //构建树形结构
        List<SysMenu> sysMenuListTree= MenuHelper.buildTree(sysMenuList);


        return sysMenuListTree;
    }

    /**
     * 新增菜单
     * @param sysMenu
     */
    @Override
    public void save(SysMenu sysMenu) {

        sysMenuMapper.save(sysMenu);
    }

    /**
     * 修改菜单
     * @param sysMenu
     */
    @Override
    public void updateById(SysMenu sysMenu) {
        sysMenuMapper.updateById(sysMenu);
    }

    /**
     * 根据id删除菜单
     * @param id
     */

    @Override
    public void removeById(Long id) {

        //根据当前菜单id查询其子菜单的数量
        Long count =sysMenuMapper.selectCountById(id);
        //判断如果有子菜单不删除，抛出异常，前端提示
        if(count>0){
            throw  new GuiguException(ResultCodeEnum.NODE_ERROR);
        }

        //删除
        sysMenuMapper.removeById(id);


    }

    /**
     * 查询用户拥有的菜单列表
     * @return
     */
    @Override
    public List<SysMenuVo> menus() {

        //获取用户id
        Long userId= AuthContextUtil.get().getId();

        //执行查询用户id关联的菜单信息
        List<SysMenu> sysMenuList=sysMenuMapper.selectListByUserId(userId);

        //构建菜单列表tree结构
        List<SysMenu> sysMenuListTree = MenuHelper.buildTree(sysMenuList);


        //调用构建结构的方法
        List<SysMenuVo> sysMenuVoList = buildMenus(sysMenuListTree);


        return sysMenuVoList;
    }

    // 将List<SysMenu>对象转换成List<SysMenuVo>对象
    private List<SysMenuVo> buildMenus(List<SysMenu> menus) {

        List<SysMenuVo> sysMenuVoList = new LinkedList<SysMenuVo>();
        for (SysMenu sysMenu : menus) {
            SysMenuVo sysMenuVo = new SysMenuVo();
            sysMenuVo.setTitle(sysMenu.getTitle());
            sysMenuVo.setName(sysMenu.getComponent());
            List<SysMenu> children = sysMenu.getChildren();
            if (!CollectionUtils.isEmpty(children)) {
                sysMenuVo.setChildren(buildMenus(children));
            }
            sysMenuVoList.add(sysMenuVo);
        }
        return sysMenuVoList;
    }

}
