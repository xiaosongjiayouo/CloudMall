package com.atguigu.spzx.manger.demo;

import io.minio.BucketExistsArgs;
import io.minio.MakeBucketArgs;
import io.minio.MinioClient;
import io.minio.PutObjectArgs;
import io.minio.errors.*;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class FileUploadTest {

    /**
     * 1.协议
     *   https 不合适，  SSL
     * 2.bucket
     *    命名问题---    不可以加下划线 “_”
     *
     * @param args
     */
    public static void main(String[] args) {

        try {
            // 创建MinioClient客户端
            MinioClient minioClient =
                    MinioClient.builder()
                            .endpoint("http://192.168.254.153:9000")
                            .credentials("admin", "admin123456")
                            .build();

            // 判断是否存在指定的桶
            boolean found =
                    minioClient.bucketExists(BucketExistsArgs.builder().bucket("spzx-demo").build());
            if (!found) {
                // 不存在则创建'.
                minioClient.makeBucket(MakeBucketArgs.builder().bucket("spzx-demo").build());
            } else {
                System.out.println("Bucket 'asiatrip' already exists.");
            }

            //上传
            FileInputStream fis = new FileInputStream("D://01.jpg") ;
            // Upload known sized input stream.
            minioClient.putObject(
                    PutObjectArgs.builder().bucket("spzx-demo").object("001.jpg").stream(
                                    fis, fis.available(), -1)
//                            .contentType("video/mp4")
                            .build());

            //路径处理
            String fileUrl = "http://192.168.254.153:9000/spzx-demo/001.jpg" ;
            System.out.println(fileUrl);
            fis.close();

        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
