package com.atguigu.spzx.manger.service;

import com.atguigu.spzx.model.dto.order.OrderStatisticsDto;
import com.atguigu.spzx.model.vo.order.OrderStatisticsVo;

public interface OrderInfoService {
    /**
     * 查询指定时间段的订单数据
     * @param orderStatisticsDto
     * @return
     */
    OrderStatisticsVo getOrderStatisticsData(OrderStatisticsDto orderStatisticsDto);
}
