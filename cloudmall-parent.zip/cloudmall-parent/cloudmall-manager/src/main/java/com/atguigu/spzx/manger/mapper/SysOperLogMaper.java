package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.entity.system.SysOperLog;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SysOperLogMaper {
    /**
     * 保存日志信息
     * @param sysOperLog
     */
    void saveSysOperLog(SysOperLog sysOperLog);
}
