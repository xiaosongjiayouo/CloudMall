package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.entity.product.ProductDetails;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductDetailsMapper {
    /**
     * 保存商品详情
     * @param productDetails
     */
    void save(ProductDetails productDetails);

    /**
     * 根据product_id 查询商品详情信息
     * @param id
     * @return
     */
    ProductDetails selectByProductId(Long id);

    /**
     * 保存商品详情
     * @param productDetails
     */
    void updateById(ProductDetails productDetails);

    /**
     * 根据productId删除details
     * @param productId
     */
    void deleteByProductId(Long productId);
}
