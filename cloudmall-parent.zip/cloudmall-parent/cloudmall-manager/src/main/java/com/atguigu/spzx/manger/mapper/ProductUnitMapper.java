package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.entity.base.ProductUnit;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ProductUnitMapper {
    /**
     * 查询所有计量单位
     * @return
     */
    List<ProductUnit> findAll();
}
