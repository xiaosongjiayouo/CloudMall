package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.dto.system.AssginMenuDto;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SysRoleMenuMapper {
    /**
     * 查询当前角色拥有的菜单id列表
     * @param roleId
     * @return
     */
    List<Long> findSysRoleMenuByRoleId(Long roleId);

    /**
     * 删除指定角色拥有的菜单
     * @param roleId
     */
    void deleteMenuIdsByRoleId(Long roleId);

    /**
     * 保存指定角色分配的菜单
     * @param assginMenuDto
     */
    void doAssign(AssginMenuDto assginMenuDto);

}
