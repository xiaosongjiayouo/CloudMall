package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.entity.product.ProductSku;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ProductSkuMapper {
    /**
     * 保存sku
     * @param productSku
     */
    void save(ProductSku productSku);

    /**
     * 根据product_id 查询商品详情信息
     * @param id
     * @return
     */
    List<ProductSku> selectByProductId(Long id);

    /**
     * 保存sku信息
     * @param productSku
     */
    void updateById(ProductSku productSku);


    /**
     * 根据proudctId删除productSku
     * @param productId
     */
    void deleteByProductId(Long productId);
}
