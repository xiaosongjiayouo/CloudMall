package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.entity.system.SysMenu;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SysMenuMapper {
    /**
     * 查询所有的菜单
     * @return
     */
    List<SysMenu> findNodes();

    /**
     * 新增菜单
     * @param sysMenu
     */
    void save(SysMenu sysMenu);

    /**
     * sysMenuMapper
     * @param sysMenu
     */
    void updateById(SysMenu sysMenu);

    /**
     * 统计子节点数据
     * @param id
     * @return
     */
    Long selectCountById(Long id);

    /**
     * 删除节点
     * @param id
     */
    void removeById(Long id);

    /**
     * 执行查询用户id关联的菜单信息
     * @param userId
     * @return
     */
    List<SysMenu> selectListByUserId(Long userId);
}
