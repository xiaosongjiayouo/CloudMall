package com.atguigu.spzx.manger.helper;

import com.atguigu.spzx.model.entity.system.SysMenu;

import java.util.ArrayList;
import java.util.List;

public class MenuHelper {
    /**
     * 构建树形结构
     * @param sysMenuList
     * @return
     */
    public static List<SysMenu> buildTree(List<SysMenu> sysMenuList) {

        List<SysMenu> sysMenuListTree=new ArrayList<>();
        //遍历菜单集合
        for (SysMenu sysMenu : sysMenuList) {
            //获取一级菜单
            if(sysMenu.getParentId().intValue()==0){
                //构建当前菜单的子集列表children
                SysMenu sysMenuTree = findChildren(sysMenu, sysMenuList);
                sysMenuListTree.add(sysMenuTree);

            }

        }



        return sysMenuListTree;
    }

    /**
     * 获取指定菜单sysMenu的子菜单，并且将子菜单存储到sysMenu的children
     *
     * private List<SysMenu> children;
     * @param sysMenu
     * @param sysMenuList
     * @return
     */
    private static SysMenu findChildren(SysMenu sysMenu, List<SysMenu> sysMenuList) {
        //创建子菜单集合
        List<SysMenu> children=new ArrayList<>();
        //判断是否为当前菜单的子菜单
        for (SysMenu menu : sysMenuList) {
            if(sysMenu.getId().intValue()==menu.getParentId().intValue()){

                children.add(menu);
                //递归处理多级菜单
//                children.add(findChildren(menu,sysMenuList));

            }

        }

        sysMenu.setChildren(children);
        return sysMenu;
    }
}
