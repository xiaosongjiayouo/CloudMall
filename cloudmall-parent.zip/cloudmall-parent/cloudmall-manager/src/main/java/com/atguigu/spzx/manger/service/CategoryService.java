package com.atguigu.spzx.manger.service;

import com.atguigu.spzx.model.entity.product.Category;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface CategoryService {
    /**
     * 根据父级id查询下属子级分类列表
     * @param parentId
     * @return
     */
    List<Category> findCategoryListByParentId(Long parentId);

    /**
     * 导出excel
     * @param response
     */
    void exportData(HttpServletResponse response);

    /**
     * 分类管理excel导入
     * @param file
     */
    void importData(MultipartFile file);
}
