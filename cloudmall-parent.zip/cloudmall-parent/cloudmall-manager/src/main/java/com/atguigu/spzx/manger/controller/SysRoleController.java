package com.atguigu.spzx.manger.controller;

import com.atguigu.spzx.manger.service.SysRoleService;
import com.atguigu.spzx.model.dto.system.SysRoleDto;
import com.atguigu.spzx.model.entity.system.SysRole;
import com.atguigu.spzx.model.vo.common.Result;
import com.atguigu.spzx.model.vo.common.ResultCodeEnum;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/system/sysRole")
public class SysRoleController {


    @Autowired
    private SysRoleService sysRoleService;


    /**
     * 查询所有的角色
     * @return
     */
    @GetMapping("/findAllRoles/{userId}")
    public Result<Map<String,Object>> findAllRoles(@PathVariable Long userId){
       Map<String,Object> resultMap =sysRoleService.findAllRoles(userId);

        return Result.build(resultMap,ResultCodeEnum.SUCCESS);
    }


    /**
     * 根据id删除角色
     * @param id
     * @return
     */
    @DeleteMapping("/deleteSysRoleById/{id}")
    public Result deleteSysRoleById(@PathVariable Long id){
            sysRoleService.deleteSysRoleById(id);

        return Result.build(null,ResultCodeEnum.SUCCESS);
    }

    /**
     * 修改保存
     * @param sysRole
     * @return
     */
    @PutMapping("/updateSysRole")
    public Result updateSysRole(@RequestBody SysRole sysRole){

        sysRoleService.updateSysRole(sysRole);
        return Result.build(null,ResultCodeEnum.SUCCESS);
    }

    /**
     * 保存角色
     * @param sysRole
     * @return
     */
    @PostMapping("/saveSysRole")
    public Result saveSysRole(@RequestBody SysRole sysRole ){

        sysRoleService.saveSysRole(sysRole);

        return Result.build(null,ResultCodeEnum.SUCCESS);

    }


    /**
     * 条件分页查询角色列表
     * @param sysRoleDto
     * @param pageNum
     * @param pageSize
     * @return
     */
    @GetMapping("/findByPage/{pageNum}/{pageSize}")
    public Result<PageInfo<SysRole>> findByPage(SysRoleDto sysRoleDto,
                                                @PathVariable Integer pageNum,
                                                @PathVariable Integer pageSize,
                                                @RequestHeader(name = "token")String token){
        PageInfo<SysRole> rolePageInfo=sysRoleService.findByPage(sysRoleDto,pageNum,pageSize);

        return Result.build(rolePageInfo, ResultCodeEnum.SUCCESS);

    }
}
