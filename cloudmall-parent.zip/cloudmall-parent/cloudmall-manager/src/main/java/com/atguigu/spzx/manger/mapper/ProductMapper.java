package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.dto.product.ProductDto;
import com.atguigu.spzx.model.entity.product.Product;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ProductMapper {
    /**
     * 条件分页查询商品列表
     * @param productDto
     * @return
     */
    List<Product> findByPage(ProductDto productDto);

    /**
     * 保存商品信息
     * @param product
     */
    void save(Product product);

    Product selectByProductId(Long id);

    /**
     *
     * @param product
     */
    void updateById(Product product);

    /**
     * 删除商品
     * @param id
     */
    void deleteById(Long id);
}
