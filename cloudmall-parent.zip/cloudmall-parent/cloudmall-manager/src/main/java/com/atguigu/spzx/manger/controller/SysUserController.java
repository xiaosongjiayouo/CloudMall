package com.atguigu.spzx.manger.controller;

import com.atguigu.spzx.manger.service.SysUserService;
import com.atguigu.spzx.model.dto.system.SysUserDto;
import com.atguigu.spzx.model.entity.system.SysUser;
import com.atguigu.spzx.model.vo.common.Result;
import com.atguigu.spzx.model.vo.common.ResultCodeEnum;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin/system/sysUser")
public class SysUserController {


    @Autowired
    private SysUserService sysUserService;

    /**
     * 根据id删除用户
     * @param userId
     * @return
     */
    @DeleteMapping("/deleteById/{userId}")
    public Result deleteById(@PathVariable Long userId){

        sysUserService.deleteById(userId);
        return Result.build(null,ResultCodeEnum.SUCCESS);
    }


    /**
     * 修改用户信息
     * @param sysUser
     * @return
     */
    @PutMapping("/updateSysUser")
    public Result updateSysUser(@RequestBody SysUser sysUser){

        sysUserService.updateSysUser(sysUser);
        return Result.build(null,ResultCodeEnum.SUCCESS);
    }


    /**
     * 新增用户
     * @param sysUser
     * @return
     */
    @PostMapping("/saveSysUser")
    public Result saveSysUser(@RequestBody SysUser sysUser){

        sysUserService.saveSysUser(sysUser);
        return Result.build(null,ResultCodeEnum.SUCCESS);
    }

    /**
     * 条件分页查询用户
     * @param sysUserDto
     * @param pageNum
     * @param pageSize
     * @return
     */
    @GetMapping("/findByPage/{pageNum}/{pageSize}")
    public Result<PageInfo<SysUser>> findByPage(SysUserDto sysUserDto,
                                                @PathVariable Integer pageNum,
                                                @PathVariable Integer pageSize){

        PageInfo<SysUser> pageInfo=sysUserService.findByPage(sysUserDto,pageNum,pageSize);

        return  Result.build(pageInfo, ResultCodeEnum.SUCCESS);

    }

}
