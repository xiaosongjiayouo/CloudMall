package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.entity.order.OrderStatistics;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface OrderInfoMapper {
    /**
     * 统计指定时间的订单信息
     * @param dateTime
     * @return
     */
    OrderStatistics selectOrderStatistics(String dateTime);
}
