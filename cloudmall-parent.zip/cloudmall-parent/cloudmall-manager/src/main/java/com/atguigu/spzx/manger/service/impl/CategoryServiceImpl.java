package com.atguigu.spzx.manger.service.impl;

import com.alibaba.excel.EasyExcel;
import com.atguigu.spzx.manger.listener.CategoryExcelListener;
import com.atguigu.spzx.manger.listener.ExcelListener;
import com.atguigu.spzx.manger.mapper.CategoryMapper;
import com.atguigu.spzx.manger.service.CategoryService;
import com.atguigu.spzx.model.entity.product.Category;
import com.atguigu.spzx.model.vo.product.CategoryExcelVo;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CategoryServiceImpl implements CategoryService {
    @Autowired
    private CategoryMapper categoryMapper;
    /**
     * 根据父级id查询下属子级分类列表
     * @param parentId
     * @return
     */
    @Override
    public List<Category> findCategoryListByParentId(Long parentId) {

        //根据父级id查询下属子级分类列表
        List<Category> categoryList= categoryMapper.findCategoryListByParentId(parentId);
        //判断其中没有分类是否有下级分类
        for (Category category : categoryList) {
            //根据当前分类的id，去统计其子级分类的数据量
            Long coutn=categoryMapper.countByParentId(category.getId());
            //判断
            if(coutn.intValue()<=0){

                category.setHasChildren(false);
            }else{
                category.setHasChildren(true);
            }


        }

        return categoryList;
    }

    /**
     * 导出excel---写的api
     * 注意：此时并不涉及到监听器回调
     * 涉及的Api:
     *
     *  EasyExcel.write(response.getOutputStream(), DownloadData.class).sheet("模板").doWrite(data());
     *  参数一：响应流对象
     *  参数二：实体类字节码
     *  参数三：sheet名称
     *  参数四：list集合数据
     *
     *
     *  stream:
     *       常用的两个API:
     *        1.map()
     *        如果处理的集合和处理后的集合类型不同可以选择使用map()
     *
     * List<Category> categoryList=------>List<CategoryExcelVo>
     *
     *       2.filter()
     *    如果处理的集合和处理后的集合类型相同可以选择使用 filter（）
     *        10个对象 ---符合条件 ---2个
     *
     *
     * collect(Collectors.toList()):
     *  将遍历中的对象存储到list集合并返回
     *
     *   BeanUtils.copyProperties(category,excelVo);
     *   拷贝数据的方法；
     *   可以将参数一对象数据拷贝到参数二中
     *   要求：属性必须一致
     *
     *
     *
     * @param response
     */
    @Override
    public void exportData(HttpServletResponse response) {

        try {


            //2.响应数据到浏览器的设置 utf-8

            //2.1 设置响应的mime类型
            response.setContentType("application/vnd.ms-excel");
            //设置服务器响应内容按照utf-8进行编码
            response.setCharacterEncoding("utf-8");


            //2.2设置中文乱码
            String fileName = URLEncoder.encode("分类数据", "UTF-8");
            //告诉浏览接收数据后，安装下载的方式进行处理，不要直接在浏览器页面中进行渲染
            response.setHeader("Content-disposition", "attachment;filename=" + fileName + ".xlsx");


            //1.准备数据
            //查询所有分类
            List<Category> categoryList=  categoryMapper.selectCategoryList();
            //转换数据为CategoryExcelVo
            List<CategoryExcelVo> categoryExcelVoList = categoryList.stream().map(category -> {
                //创建excel实体类
                CategoryExcelVo excelVo = new CategoryExcelVo();
                //拷贝数据
                BeanUtils.copyProperties(category, excelVo);
                return excelVo;
            }).collect(Collectors.toList());

            //2.写出数据
            EasyExcel.write(response.getOutputStream(), CategoryExcelVo.class).sheet("分类数据").doWrite(categoryExcelVoList);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }


    }

    /**
     * 分类管理excel导入
     *
     * EasyExcel的读取
     * 1.定义实体类
     * CategoryExcelVo
     * 2.定义监听器回调
     *
     * 3.读取
     * 4.写入数据库
     *
     *
     *
     * @param file
     */
    @Override
    public void importData(MultipartFile file) {


        try {
            //创建监听器回调
            CategoryExcelListener excelListener = new CategoryExcelListener(categoryMapper);

            EasyExcel.read(file.getInputStream(), CategoryExcelVo.class, excelListener).sheet().doRead();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
