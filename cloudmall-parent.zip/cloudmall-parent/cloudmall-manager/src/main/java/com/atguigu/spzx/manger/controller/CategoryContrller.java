package com.atguigu.spzx.manger.controller;

import com.atguigu.spzx.manger.service.CategoryService;
import com.atguigu.spzx.model.entity.product.Category;
import com.atguigu.spzx.model.vo.common.Result;
import com.atguigu.spzx.model.vo.common.ResultCodeEnum;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/admin/product/category")
public class CategoryContrller {

    @Autowired
    private CategoryService categoryService;


    /**
     *
     http://localhost:8501/admin/product/category/importData
     * 分类管理excel导入
     * @param file
     * @return
     */
    @PostMapping("/importData")
    public Result importData(MultipartFile file){

        categoryService.importData(file);

        return  Result.build(null,ResultCodeEnum.SUCCESS);
    }
    /**
     * 分类导出excel
     * @param response
     */
    @GetMapping("/exportData")
    public void exportData(HttpServletResponse response){
        categoryService.exportData(response);

    }

    /**
     * 根据父级id查询下属子级分类列表
     * @return
     */
    @GetMapping("/findCategoryListByParentId/{parentId}")
    public Result<List<Category>> findCategoryListByParentId(@PathVariable Long parentId){

        List<Category> categoryList=categoryService.findCategoryListByParentId(parentId);


        return Result.build(categoryList, ResultCodeEnum.SUCCESS);
    }
}
