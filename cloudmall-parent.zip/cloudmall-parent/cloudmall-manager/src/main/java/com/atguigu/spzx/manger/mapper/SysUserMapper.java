package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.dto.system.SysUserDto;
import com.atguigu.spzx.model.entity.system.SysUser;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SysUserMapper {
    /**
     * 用户登录
     * @param userName
     * @return
     */
    SysUser selectSysUserByUserName(String userName);

    /**
     * 条件分页查询用户
     * @param sysUserDto
     * @return
     */
    List<SysUser> findByPage(SysUserDto sysUserDto);

    /**
     * 新增用户
     * @param sysUser
     */
    void saveSysUser(SysUser sysUser);

    /**
     * 修改用户
     * @param sysUser
     */
    void updateSysUser(SysUser sysUser);

    /**
     * 根据id删除用户
     * @param userId
     */
    void deleteById(Long userId);
}
