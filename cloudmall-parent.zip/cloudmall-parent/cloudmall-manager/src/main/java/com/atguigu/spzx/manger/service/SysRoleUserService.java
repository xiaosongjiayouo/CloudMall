package com.atguigu.spzx.manger.service;

import com.atguigu.spzx.model.dto.system.AssginRoleDto;

public interface SysRoleUserService {
    /**
     * 保存分配角色
     * @param assginRoleDto
     */
    void doAssign(AssginRoleDto assginRoleDto);

}
