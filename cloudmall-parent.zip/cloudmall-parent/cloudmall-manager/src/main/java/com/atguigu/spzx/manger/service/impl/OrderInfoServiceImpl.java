package com.atguigu.spzx.manger.service.impl;

import cn.hutool.core.date.DateUtil;
import com.atguigu.spzx.manger.mapper.OrderStatisticsMapper;
import com.atguigu.spzx.manger.service.OrderInfoService;
import com.atguigu.spzx.model.dto.order.OrderStatisticsDto;
import com.atguigu.spzx.model.entity.order.OrderStatistics;
import com.atguigu.spzx.model.vo.order.OrderStatisticsVo;
import com.atguigu.spzx.service.exception.GuiguException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderInfoServiceImpl implements OrderInfoService {

    @Autowired
    private OrderStatisticsMapper orderStatisticsMapper;

    /**
     * 查询指定时间段的订单数据
     * @param orderStatisticsDto
     * @return
     */
    @Override
    public OrderStatisticsVo getOrderStatisticsData(OrderStatisticsDto orderStatisticsDto) {

        //查询指定时间段的订单统计结果
        List<OrderStatistics>  orderStatisticsList=orderStatisticsMapper.getOrderStatisticsData(orderStatisticsDto);
        //从结果中获取时间数据 Stream

        if(CollectionUtils.isEmpty(orderStatisticsList)){
            throw new GuiguException(229,"所选时间段内没有订单数据");
        }

        List<String> dateList = orderStatisticsList.stream().map(orderStatistics -> {

            //对数据格式化
            String dateTime = DateUtil.format(orderStatistics.getOrderDate(), "yyyy-MM-dd");

            return dateTime;
        }).collect(Collectors.toList());
//        List<String> dateList = orderStatisticsList.stream().map(orderStatistics ->DateUtil.format(orderStatistics.getOrderDate(), "yyyy-MM-dd")).collect(Collectors.toList());

        //从结果中获取金额数据

        List<BigDecimal> amountList = orderStatisticsList.stream().map(orderStatistics -> {

            return orderStatistics.getTotalAmount();
        }).collect(Collectors.toList());


        //封装结果OrderStatisticsVo
        OrderStatisticsVo orderStatisticsVo=new OrderStatisticsVo();
        orderStatisticsVo.setDateList(dateList);
        orderStatisticsVo.setAmountList(amountList);


        return orderStatisticsVo;
    }
}
