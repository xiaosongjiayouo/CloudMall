package com.atguigu.spzx.manger.service;

import com.atguigu.spzx.model.entity.product.ProductSpec;
import com.github.pagehelper.PageInfo;

import java.util.List;

public interface ProductSpecService {
    /**
     * 分页查询商品规格
     * @param pageNum
     * @param pageSize
     * @return
     */
    PageInfo<ProductSpec> findByPage(Integer pageNum, Integer pageSize);

    /**
     * 商品规格新增
     * @param productSpec
     */
    void save(ProductSpec productSpec);

    /**
     * 修改商品规格
     * @param productSpec
     */
    void updateById(ProductSpec productSpec);

    /**
     * 删除规格
     * @param id
     */
    void deleteById(Long id);

    /**
     * 查询所有规格
     * @return
     */
    List<ProductSpec> findAll();

}
