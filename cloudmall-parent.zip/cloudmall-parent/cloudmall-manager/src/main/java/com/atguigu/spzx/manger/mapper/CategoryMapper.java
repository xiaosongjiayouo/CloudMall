package com.atguigu.spzx.manger.mapper;

import com.atguigu.spzx.model.entity.product.Category;
import com.atguigu.spzx.model.vo.product.CategoryExcelVo;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CategoryMapper {
    /**
     * 根据父级id查询下属子级分类列表
     * @param parentId
     * @return
     */
    List<Category> findCategoryListByParentId(Long parentId);

    /**
     * 根据当前分类的id，去统计其子级分类的数据量
     * @param id
     * @return
     */
    Long countByParentId(Long id);

    /**
     * 查询所有分类
     * @return
     */
    List<Category> selectCategoryList();


    void batchInsert(List<CategoryExcelVo> cachedDataList);
}
