package com.atguigu.spzx.manger.controller;

import com.atguigu.spzx.manger.service.SysMenuService;
import com.atguigu.spzx.manger.service.SysUserService;
import com.atguigu.spzx.manger.service.ValidateCodeService;
import com.atguigu.spzx.model.dto.system.LoginDto;
import com.atguigu.spzx.model.entity.system.SysUser;
import com.atguigu.spzx.model.vo.common.Result;
import com.atguigu.spzx.model.vo.common.ResultCodeEnum;
import com.atguigu.spzx.model.vo.system.LoginVo;
import com.atguigu.spzx.model.vo.system.SysMenuVo;
import com.atguigu.spzx.model.vo.system.ValidateCodeVo;
import com.atguigu.spzx.utils.AuthContextUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/system/index")
@Tag(name = "首页接口")
//@CrossOrigin(allowCredentials = "true",originPatterns = "*",allowedHeaders = "*")
public class IndexController {

    @Autowired
    private SysUserService sysUserService;
    @Autowired
    private ValidateCodeService validateCodeService;

    @Autowired
    private SysMenuService sysMenuService;


    /**
     * 查询用户拥有的菜单列表
     * @return
     */
    @GetMapping("/menus")
    public Result<List<SysMenuVo>> menus(){

        List<SysMenuVo>sysMenuVoList= sysMenuService.menus();


        return Result.build(sysMenuVoList,ResultCodeEnum.SUCCESS);
    }

    /**
     * 用户退出
     * @param token
     * @return
     */
    @GetMapping("/logout")
    public Result logout(@RequestHeader(name="token")String token){

        sysUserService.loginOut(token);

        return Result.build(null,ResultCodeEnum.SUCCESS);
    }



    /**
     * 获取用户信息
     * /admin/system/index/userinfo
     * @param token
     * @return
     */
    @GetMapping("/userinfo")
    public Result<SysUser> getUserInfo(@RequestHeader(name = "token") String token){

//        SysUser sysUser=sysUserService.getUserInfo(token);
        SysUser sysUser = AuthContextUtil.get();


        return Result.build(sysUser,ResultCodeEnum.SUCCESS);
    }



    /**
     * /admin/system/index/generateValidateCode
     * 获取验证码
     * @return
     */
    @GetMapping("/generateValidateCode")
    public Result<ValidateCodeVo> generateValidateCode(){
        ValidateCodeVo validateCodeVo= validateCodeService.generateValidateCode();

        return Result.build(validateCodeVo, ResultCodeEnum.SUCCESS);

    }
    /**
     * 用户登录
     * @param loginDto
     * @return
     */
    @PostMapping("/login")
    @Operation(summary = "用户登录")
    public Result<LoginVo> login(@RequestBody LoginDto loginDto){

        LoginVo loginVo =sysUserService.login(loginDto);


        return Result.build(loginVo, ResultCodeEnum.SUCCESS);
    }
}
