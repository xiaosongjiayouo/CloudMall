package com.atguigu.spzx.manger.controller;

import com.atguigu.spzx.manger.service.CategoryBrandService;
import com.atguigu.spzx.model.dto.product.CategoryBrandDto;
import com.atguigu.spzx.model.entity.product.Brand;
import com.atguigu.spzx.model.entity.product.CategoryBrand;
import com.atguigu.spzx.model.vo.common.Result;
import com.atguigu.spzx.model.vo.common.ResultCodeEnum;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/product/categoryBrand")
public class CategoryBrandController {

    @Autowired
    private CategoryBrandService categoryBrandService;

    /**
     * 根据分类查询品牌列表
     * @param categoryId
     * @return
     */
    @GetMapping("/findBrandByCategoryId/{categoryId}")
    public Result<List<Brand>> findBrandByCategoryId(@PathVariable Long categoryId){

        List<Brand> brandList=categoryBrandService.findBrandByCategoryId(categoryId);
        return Result.build(brandList,ResultCodeEnum.SUCCESS);
    }

    /**
     * 删除分类品牌
     * @param id
     * @return
     */
    @DeleteMapping("/deleteById/{id}")
    public Result deleteById(@PathVariable Long id){

        categoryBrandService.deleteById(id);
        return Result.build(null,ResultCodeEnum.SUCCESS);
    }
    /**
     * 修改分类品牌
     * @param categoryBrand
     * @return
     */
    @PutMapping("/updateById")
    public Result updateById(@RequestBody CategoryBrand categoryBrand){

        categoryBrandService.updateById(categoryBrand);
        return Result.build(null,ResultCodeEnum.SUCCESS);
    }
    /**
     * 新增分类品牌
     * @param categoryBrand
     * @return
     */
    @PostMapping("/save")
    public Result save(@RequestBody CategoryBrand categoryBrand){

        categoryBrandService.save(categoryBrand);

        return Result.build(null,ResultCodeEnum.SUCCESS);
    }




    /**
     * 分页条件查询分类品牌列表
     * @param page
     * @param limit
     * @param categoryBrandDto
     * @return
     */
    @GetMapping("/{page}/{limit}")
    public Result<PageInfo<CategoryBrand>> findByPage(@PathVariable Integer page,
                                                      @PathVariable Integer limit,
                                                      CategoryBrandDto categoryBrandDto){

        PageInfo<CategoryBrand> categoryBrandPageInfo=categoryBrandService.findByPage(page,limit,categoryBrandDto);

        return Result.build(categoryBrandPageInfo, ResultCodeEnum.SUCCESS);
    }
}
