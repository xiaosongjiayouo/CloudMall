package com.atguigu.spzx.manger.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import lombok.Getter;


import java.util.ArrayList;
import java.util.List;
public class ExcelListener<T> extends AnalysisEventListener<T> {


    //定义一个集合收集数据
    List<T> datas=new ArrayList<>();


    public List<T> getDatas(){

        return datas;
    }

    /**
     * 每读取一行数据，监听回调就会执行一次
     * @param t 读取的一行数据
     * @param analysisContext
     */
    @Override
    public void invoke(T t, AnalysisContext analysisContext) {


        datas.add(t);
    }

    /**
     * 在解析完成后执行一次，主要用户释放资源，或者进行最终读取时的补充使用
     * @param analysisContext
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {

        System.out.println("excel解析完成了。。。。");
    }
}
