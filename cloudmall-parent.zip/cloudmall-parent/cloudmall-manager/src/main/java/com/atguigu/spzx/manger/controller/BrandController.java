package com.atguigu.spzx.manger.controller;

import com.atguigu.spzx.common.log.annotation.Log;
import com.atguigu.spzx.manger.service.BrandService;
import com.atguigu.spzx.model.entity.product.Brand;
import com.atguigu.spzx.model.entity.system.SysOperLog;
import com.atguigu.spzx.model.vo.common.Result;
import com.atguigu.spzx.model.vo.common.ResultCodeEnum;
import com.github.pagehelper.PageInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/product/brand")

public class BrandController {

    @Autowired
    private BrandService brandService;




    /**
     * 查询所有品牌
     * @return
     */
    @GetMapping("/findAll")

    public Result<List<Brand>> findAll(){

        List<Brand> brandList=brandService.findAll();
        return Result.build(brandList,ResultCodeEnum.SUCCESS);
    }

    /**
     * 根据id删除品牌
     * @param id
     * @return
     */
    @DeleteMapping("/deleteById/{id}")
    public Result deleteById(@PathVariable Long id ){

        brandService.deleteById(id);
        return Result.build(null,ResultCodeEnum.SUCCESS);
    }

    /**
     * 修改品牌
     * @param brand
     * @return
     */
    @PutMapping("/updateById")
    public Result updateById(@RequestBody Brand brand){


        brandService.updateById(brand);

        return Result.build(null,ResultCodeEnum.SUCCESS);
    }

    /**
     * 新增品牌
     * @param brand
     * @return
     */
    @PostMapping("/save")
   @Transactional
    public Result save(@RequestBody Brand brand){

        SysOperLog sysOperLog=new SysOperLog();
        sysOperLog.setTitle("品牌模块");
        sysOperLog.setMethod("save");
        sysOperLog.setRequestMethod("get");

//        sysOperLogMapper.insert(sysOperLog);

        brandService.save(brand);

        return Result.build(null,ResultCodeEnum.SUCCESS);

    }
    /**
     * 分页查询品牌列表
     * @param pageNum
     * @param pageSize
     * @return
     *

     *
     *
     */
    @GetMapping("/{pageNum}/{pageSize}")
    @Log( title ="品牌模块-查询方法",businessType = 0,isSaveRequestData = false)
    public Result<PageInfo<Brand>> findByPage(@PathVariable Integer pageNum,
                                                    @PathVariable Integer pageSize){

//        int i=1/0;
        PageInfo<Brand> pageInfo=brandService.findByPage(pageNum,pageSize);

        return Result.build(pageInfo, ResultCodeEnum.SUCCESS);
    }
}
