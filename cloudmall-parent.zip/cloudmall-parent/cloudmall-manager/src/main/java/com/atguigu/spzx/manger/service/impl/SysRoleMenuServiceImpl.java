package com.atguigu.spzx.manger.service.impl;

import com.atguigu.spzx.manger.mapper.SysRoleMenuMapper;
import com.atguigu.spzx.manger.service.SysMenuService;
import com.atguigu.spzx.manger.service.SysRoleMenuService;
import com.atguigu.spzx.model.dto.system.AssginMenuDto;
import com.atguigu.spzx.model.entity.system.SysMenu;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SysRoleMenuServiceImpl implements SysRoleMenuService {

    @Autowired
    private SysMenuService sysMenuService;

    @Autowired
    private SysRoleMenuMapper sysRoleMenuMapper;


    /**
     * 查询所有菜单和当前角色拥有的菜单id集合
     */
    @Override
    public Map<String, Object> findSysRoleMenuByRoleId(Long roleId) {

        Map<String, Object> resultMap=new HashMap<>();

        //查询所有菜单的列表tree
        List<SysMenu> sysMenusTree = sysMenuService.findNodes();
        //查询当前角色拥有的菜单id列表
        List<Long> menuIds=sysRoleMenuMapper.findSysRoleMenuByRoleId(roleId);

        resultMap.put("sysMenusTree",sysMenusTree);
        resultMap.put("menuIds",menuIds);

        return resultMap;
    }

    /**
     * 给指定角色分配菜单
     * @param assginMenuDto
     */
    @Override
    public void doAssign(AssginMenuDto assginMenuDto) {

        //删除之前拥有的菜单
        sysRoleMenuMapper.deleteMenuIdsByRoleId(assginMenuDto.getRoleId());

        //判断
        List<Map<String, Number>> menuIdList = assginMenuDto.getMenuIdList();
        //判断
        if(!CollectionUtils.isEmpty(menuIdList)){

            sysRoleMenuMapper.doAssign(assginMenuDto);
        }


    }
}
