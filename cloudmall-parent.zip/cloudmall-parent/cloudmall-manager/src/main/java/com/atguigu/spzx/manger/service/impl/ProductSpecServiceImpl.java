package com.atguigu.spzx.manger.service.impl;

import com.atguigu.spzx.manger.mapper.ProductSpecMapper;
import com.atguigu.spzx.manger.service.ProductSpecService;
import com.atguigu.spzx.model.entity.product.ProductSpec;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductSpecServiceImpl implements ProductSpecService {

    @Autowired
    private ProductSpecMapper productSpecMapper;
    /**
     * 分页查询商品规格
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public PageInfo<ProductSpec> findByPage(Integer pageNum, Integer pageSize) {
        //设置分页插件
        PageHelper.startPage(pageNum,pageSize);
        //插叙所有商品规格
        List<ProductSpec> productSpecList=productSpecMapper.findByPage();
        //构建数据
        PageInfo<ProductSpec> pageInfo=new PageInfo<>(productSpecList);

        return pageInfo;
    }

    /**
     * 商品规格新增
     * @param productSpec
     */
    @Override
    public void save(ProductSpec productSpec) {
        productSpecMapper.save(productSpec);

    }

    /**
     * 修改商品规格
     * @param productSpec
     */
    @Override
    public void updateById(ProductSpec productSpec) {

        productSpecMapper.updateById(productSpec);
    }

    /**
     * 删除规格
     * @param id
     */
    @Override
    public void deleteById(Long id) {
        productSpecMapper.deleteById(id);
    }

    /**
     * 查询所有规格
     * @return
     */
    @Override
    public List<ProductSpec> findAll() {
        return productSpecMapper.findAll();
    }
}
