package com.atguigu.spzx.manger.service;

import com.atguigu.spzx.model.dto.product.ProductDto;
import com.atguigu.spzx.model.entity.product.Product;
import com.github.pagehelper.PageInfo;

public interface ProductService {
    /**
     * 条件分页查询商品列表
     * @param pageNum
     * @param pageSize
     * @param productDto
     * @return
     */
    PageInfo<Product> findByPage(Integer pageNum, Integer pageSize, ProductDto productDto);

    /**
     * 保存商品
     * @param product
     */
    void save(Product product);

    /**
     * 根据id查询商品对象
     * @param id
     * @return
     */
    Product getProductById(Long id);

    /**
     *  修改保存
     * @param product
     */
    void updateById(Product product);

    /**
     * 根据id删除商品信息
     * @param id
     */
    void deleteById(Long id);

    /**
     * 商品审核
     * @param id
     * @param auditStatus
     */
    void updateAuditStatus(Long id, Integer auditStatus);

    /**
     * 商品上下架
     * @param id
     * @param status
     */
    void updateStatus(Long id, Integer status);
}
