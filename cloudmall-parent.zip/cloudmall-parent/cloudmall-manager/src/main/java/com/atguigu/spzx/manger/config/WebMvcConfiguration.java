package com.atguigu.spzx.manger.config;

import com.atguigu.spzx.manger.interceptor.LoginAuthInterceptor;
import com.atguigu.spzx.manger.properties.UserAuthProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Component
public class WebMvcConfiguration implements WebMvcConfigurer {

    @Autowired
    private UserAuthProperties userAuthProperties;

    @Autowired
    private LoginAuthInterceptor loginAuthInterceptor;

    /**
     * 注册登录校验拦截器
     * @param registry
     */

    @Override
    public void addInterceptors(InterceptorRegistry registry) {



        registry.addInterceptor(loginAuthInterceptor)
                .excludePathPatterns(userAuthProperties.getNoAuthUrls())
                .addPathPatterns("/**");
    }

    /**
     * 跨域处理和设置
     * @param registry
     */
    @Override
    public void addCorsMappings(CorsRegistry registry) {

        registry.addMapping("/**") //拦截映射路径规则
                .allowedHeaders("*") //允许的头
                .allowedMethods("*") //允许的请求方式
                .allowedOriginPatterns("*") //允许的请求源
                .allowCredentials(true); //是否允许携带cookie

    }
}
