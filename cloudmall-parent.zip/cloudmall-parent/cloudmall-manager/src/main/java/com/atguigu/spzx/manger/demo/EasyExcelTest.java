package com.atguigu.spzx.manger.demo;

import com.alibaba.excel.EasyExcel;
import com.atguigu.spzx.manger.listener.ExcelListener;
import com.atguigu.spzx.model.vo.product.CategoryExcelVo;

import java.util.ArrayList;
import java.util.List;

public class EasyExcelTest {

    public static void main(String[] args) {



//         readExcelDemo();

        wirteExcelDemo();


    }

    private static void wirteExcelDemo() {

        //准备数据
        List<CategoryExcelVo> list = new ArrayList<>() ;
        list.add(new CategoryExcelVo(1L , "数码办公" , "",0L, 1, 1)) ;
        list.add(new CategoryExcelVo(11L , "华为手机" , "",1L, 1, 2)) ;

        //写出实现
        EasyExcel.write("D:\\分类数据0901.xlsx", CategoryExcelVo.class).sheet("分类管理").doWrite(list);

        System.out.println("写出完毕");


    }

    private static void readExcelDemo() {

        //定义文件的位置
        String fileName="D:\\分类数据1.xlsx";
        //创建监听器
        ExcelListener<CategoryExcelVo> excelListener=new ExcelListener<>();

        //读取
        EasyExcel.read(fileName, CategoryExcelVo.class,excelListener).sheet().doRead();
        //获取数据
        List<CategoryExcelVo> datas = excelListener.getDatas();
        for (CategoryExcelVo data : datas) {
            System.out.println(data);
        }

    }
}
